define(function(require, exports, module) {
  	seajs.use(['bootstrap/css/bootstrap.min.css','bootstrap/css/bootstrap-theme.min.css',"bootstrap/js/bootstrap.min.js"]);
  	var util = {};

  // 暴露对应接口
  module.exports = util;
});